package kz.aitu.oop.assignment6;

public class ModernSofa implements Sofa {
    @Override
    public void beauty() {
        System.out.println("The sofa is very beautiful");
    }
}