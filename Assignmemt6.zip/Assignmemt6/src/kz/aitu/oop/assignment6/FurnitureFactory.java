package kz.aitu.oop.assignment6;

public interface FurnitureFactory{
    public Sofa createSofa();
    public Chair createChair();
    public CoffeeTable createCoffeeTable();
}