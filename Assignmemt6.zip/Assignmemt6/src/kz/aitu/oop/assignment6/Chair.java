package kz.aitu.oop.assignment6;

public interface Chair {
    public void beauty();
}