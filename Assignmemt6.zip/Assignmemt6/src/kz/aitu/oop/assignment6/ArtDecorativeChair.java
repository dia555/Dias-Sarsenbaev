package kz.aitu.oop.assignment6;

public class ArtDecorativeChair implements Chair {
    @Override
    public void beauty() {
        System.out.println("The chair is very beautiful");
    }
}