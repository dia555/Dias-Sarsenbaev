package kz.aitu.oop.assignment6;

public class ArtDecorativeSofa implements Sofa{
    @Override
    public void beauty() {
        System.out.println("The sofa is very beautiful");
    }
}