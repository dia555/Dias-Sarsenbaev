package kz.aitu.oop.assignment6;

public class ArtDecotariveFF implements FurnitureFactory{
    @Override
    public Chair createChair() {
        return new ArtDecorativeChair();
    }

    @Override
    public Sofa createSofa() {
        return new ArtDecorativeSofa();
    }

    @Override
    public CoffeeTable createCoffeeTable() {
        return new ArtDecorativeCoffeTable();
    }
}