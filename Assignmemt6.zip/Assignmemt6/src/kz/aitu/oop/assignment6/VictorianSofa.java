package kz.aitu.oop.assignment6;

public class VictorianSofa implements Sofa {
    @Override
    public void beauty() {
        System.out.println("The sofa is very beautiful");
    }
}