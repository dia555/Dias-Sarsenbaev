package kz.aitu.oop.assignment6;

public class ModernCoffeTable implements CoffeeTable{
    @Override
    public void beauty() {
        System.out.println("Coffee table beautiful");
    }
}