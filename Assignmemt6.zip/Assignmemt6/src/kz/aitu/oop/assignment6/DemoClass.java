package kz.aitu.oop.assignment6;

public class DemoClass {

    public static void main(String[] args) {
        FurnitureFactory FurFact = new ArtDecotariveFF();
        Chair ArtChair = FurFact.createChair();

        ArtChair.beauty();
    }
}